const generateBtn = document.getElementById('generateBtn');
const saveBtn = document.getElementById('saveBtn');
const outputDiv = document.getElementById('output');

const templates = {
  summary: (topic, level) => `Summarize the topic "${topic}" for ${level} students.`,
  quiz: (topic, level) => `Create a quiz about "${topic}" for ${level} students.`,
  flashcards: (topic, level) => `Generate 5 flashcards on "${topic}" for ${level} students.`,
  explain: (topic, level) => `Explain "${topic}" for a ${level} student.`,
  lesson_plan: (topic, level) => `Write a lesson plan about "${topic}" for ${level} students.`
};

generateBtn.addEventListener('click', async () => {
  const topic = document.getElementById('topic').value.trim();
  const level = document.getElementById('level').value.trim();
  const type = document.getElementById('type').value;

  const prompt = templates[type](topic, level);

  try {
    const res = await fetch('http://localhost:3000/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt })
    });

    const data = await res.json();
    outputDiv.textContent = data.output || 'No output returned.';

    // Save output content to dataset for downloading
    saveBtn.dataset.output = data.output || '';

  } catch (err) {
    console.error('Frontend Error:', err);
    outputDiv.textContent = 'Failed to fetch from server.';
  }
});

// ✅ Save Output Function
function saveOutput() {
  const text = saveBtn.dataset.output || '';
  if (!text) {
    alert('There is no content to save yet.');
    return;
  }

  const blob = new Blob([text], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'generated_output.txt';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ✅ Add Save Button Listener
saveBtn.addEventListener('click', saveOutput);
